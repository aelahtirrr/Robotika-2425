class EnvironmentConfiguration:
    def __init__(self, environment_dim_x, environment_dim_y):
        self.environment_dim_x = environment_dim_x
        self.environment_dim_y = environment_dim_y
