class RobotConfiguration:
    def __init__(self, x, y, theta):
        self.x = x
        self.y = y
        self.theta = theta
