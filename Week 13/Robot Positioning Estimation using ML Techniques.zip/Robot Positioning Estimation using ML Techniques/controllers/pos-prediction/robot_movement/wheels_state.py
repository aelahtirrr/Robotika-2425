class WheelsState:
    def __init__(self):
        self.pos_left_prev = 0
        self.pos_right_prev = 0
        self.pos_left = 0
        self.pos_right = 0
