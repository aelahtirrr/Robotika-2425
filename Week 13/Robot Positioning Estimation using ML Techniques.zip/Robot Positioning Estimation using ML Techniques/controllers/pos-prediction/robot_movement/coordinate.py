class Coordinate:
    def __init__(self, x, y, theta):
        self.x = x
        self.y = y
        self.theta = theta

    def print_info(self):
        print(self.x, self.y, self.theta)
